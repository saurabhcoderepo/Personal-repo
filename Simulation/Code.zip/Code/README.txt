1. Extract the zip file on your local machine. 

2. Install Jupyter notebook if its not available on your machine. 

3. Executing the code
	a. Open "Pandemic Simulation.ipynb" using Jupyter notebook
	b. The code is set to 30000 runs for 30 days and will take few hours to run. You may change it to a different replication count by changing NumSim in first cell to a suitable number. Also, change the arguements of RunPandemicSim function call in the last cell.
	c. Execute the code by going to Cell Menu --> Run All. 

4. For reference, the graphs from 30000 runs for p = 0.02 and 0.04 (for all 4 models) have shared in Graphs folder. 
